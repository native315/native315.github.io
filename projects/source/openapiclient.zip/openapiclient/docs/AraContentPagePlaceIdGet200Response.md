# AraContentPagePlaceIdGet200Response


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**api_version** | **int** |  | [optional] 
**version** | **str** |  | [optional] 
**data** | [**AraContentPagePlaceIdGet200ResponseAllOfData**](AraContentPagePlaceIdGet200ResponseAllOfData.md) |  | [optional] 

## Example

```python
from openapi_client.models.ara_content_page_place_id_get200_response import AraContentPagePlaceIdGet200Response

# TODO update the JSON string below
json = "{}"
# create an instance of AraContentPagePlaceIdGet200Response from a JSON string
ara_content_page_place_id_get200_response_instance = AraContentPagePlaceIdGet200Response.from_json(json)
# print the JSON string representation of the object
print AraContentPagePlaceIdGet200Response.to_json()

# convert the object into a dict
ara_content_page_place_id_get200_response_dict = ara_content_page_place_id_get200_response_instance.to_dict()
# create an instance of AraContentPagePlaceIdGet200Response from a dict
ara_content_page_place_id_get200_response_form_dict = ara_content_page_place_id_get200_response.from_dict(ara_content_page_place_id_get200_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


