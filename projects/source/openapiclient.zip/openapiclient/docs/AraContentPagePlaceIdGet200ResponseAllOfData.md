# AraContentPagePlaceIdGet200ResponseAllOfData


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**subtitle** | **str** |  | [optional] 
**url** | **str** |  | [optional] 
**map** | **str** |  | [optional] 
**count** | **int** |  | [optional] 
**utc_offset** | **int** |  | [optional] 
**content** | [**List[PlaceContentContentInner]**](PlaceContentContentInner.md) |  | [optional] 

## Example

```python
from openapi_client.models.ara_content_page_place_id_get200_response_all_of_data import AraContentPagePlaceIdGet200ResponseAllOfData

# TODO update the JSON string below
json = "{}"
# create an instance of AraContentPagePlaceIdGet200ResponseAllOfData from a JSON string
ara_content_page_place_id_get200_response_all_of_data_instance = AraContentPagePlaceIdGet200ResponseAllOfData.from_json(json)
# print the JSON string representation of the object
print AraContentPagePlaceIdGet200ResponseAllOfData.to_json()

# convert the object into a dict
ara_content_page_place_id_get200_response_all_of_data_dict = ara_content_page_place_id_get200_response_all_of_data_instance.to_dict()
# create an instance of AraContentPagePlaceIdGet200ResponseAllOfData from a dict
ara_content_page_place_id_get200_response_all_of_data_form_dict = ara_content_page_place_id_get200_response_all_of_data.from_dict(ara_content_page_place_id_get200_response_all_of_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


