# ChannelPlace


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**title** | **str** |  | [optional] 

## Example

```python
from openapi_client.models.channel_place import ChannelPlace

# TODO update the JSON string below
json = "{}"
# create an instance of ChannelPlace from a JSON string
channel_place_instance = ChannelPlace.from_json(json)
# print the JSON string representation of the object
print ChannelPlace.to_json()

# convert the object into a dict
channel_place_dict = channel_place_instance.to_dict()
# create an instance of ChannelPlace from a dict
channel_place_form_dict = channel_place.from_dict(channel_place_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


