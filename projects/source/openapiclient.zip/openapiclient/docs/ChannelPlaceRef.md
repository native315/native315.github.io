# ChannelPlaceRef


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**href** | **str** |  | [optional] 
**subtitle** | **str** |  | [optional] 
**map** | **str** |  | [optional] 

## Example

```python
from openapi_client.models.channel_place_ref import ChannelPlaceRef

# TODO update the JSON string below
json = "{}"
# create an instance of ChannelPlaceRef from a JSON string
channel_place_ref_instance = ChannelPlaceRef.from_json(json)
# print the JSON string representation of the object
print ChannelPlaceRef.to_json()

# convert the object into a dict
channel_place_ref_dict = channel_place_ref_instance.to_dict()
# create an instance of ChannelPlaceRef from a dict
channel_place_ref_form_dict = channel_place_ref.from_dict(channel_place_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


