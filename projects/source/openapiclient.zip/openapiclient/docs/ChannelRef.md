# ChannelRef


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**href** | **str** |  | [optional] 

## Example

```python
from openapi_client.models.channel_ref import ChannelRef

# TODO update the JSON string below
json = "{}"
# create an instance of ChannelRef from a JSON string
channel_ref_instance = ChannelRef.from_json(json)
# print the JSON string representation of the object
print ChannelRef.to_json()

# convert the object into a dict
channel_ref_dict = channel_ref_instance.to_dict()
# create an instance of ChannelRef from a dict
channel_ref_form_dict = channel_ref.from_dict(channel_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


