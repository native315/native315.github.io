# openapi_client.ChannelsApi

All URIs are relative to *http://radio.garden/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ara_content_channel_channel_id_get**](ChannelsApi.md#ara_content_channel_channel_id_get) | **GET** /ara/content/channel/{channelId} | Get a radio station&#39;s details
[**ara_content_listen_channel_id_channel_mp3_get**](ChannelsApi.md#ara_content_listen_channel_id_channel_mp3_get) | **GET** /ara/content/listen/{channelId}/channel.mp3 | Get a radio station&#39;s live broadcast stream
[**ara_content_listen_channel_id_channel_mp3_head**](ChannelsApi.md#ara_content_listen_channel_id_channel_mp3_head) | **HEAD** /ara/content/listen/{channelId}/channel.mp3 | Get a radio station&#39;s live broadcast stream


# **ara_content_channel_channel_id_get**
> AraContentChannelChannelIdGet200Response ara_content_channel_channel_id_get(channel_id)

Get a radio station's details

### Example


```python
import openapi_client
from openapi_client.models.ara_content_channel_channel_id_get200_response import AraContentChannelChannelIdGet200Response
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://radio.garden/api
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://radio.garden/api"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ChannelsApi(api_client)
    channel_id = 'channel_id_example' # str | ID of radio station to use

    try:
        # Get a radio station's details
        api_response = api_instance.ara_content_channel_channel_id_get(channel_id)
        print("The response of ChannelsApi->ara_content_channel_channel_id_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ChannelsApi->ara_content_channel_channel_id_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **channel_id** | **str**| ID of radio station to use | 

### Return type

[**AraContentChannelChannelIdGet200Response**](AraContentChannelChannelIdGet200Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ara_content_listen_channel_id_channel_mp3_get**
> ara_content_listen_channel_id_channel_mp3_get(channel_id)

Get a radio station's live broadcast stream

### Example


```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://radio.garden/api
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://radio.garden/api"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ChannelsApi(api_client)
    channel_id = 'channel_id_example' # str | ID of radio station to use

    try:
        # Get a radio station's live broadcast stream
        api_instance.ara_content_listen_channel_id_channel_mp3_get(channel_id)
    except Exception as e:
        print("Exception when calling ChannelsApi->ara_content_listen_channel_id_channel_mp3_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **channel_id** | **str**| ID of radio station to use | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/html

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**302** | Redirect response |  * Location - URL of the station&#39;s broadcast stream <br>  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ara_content_listen_channel_id_channel_mp3_head**
> ara_content_listen_channel_id_channel_mp3_head(channel_id)

Get a radio station's live broadcast stream

### Example


```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://radio.garden/api
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://radio.garden/api"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ChannelsApi(api_client)
    channel_id = 'channel_id_example' # str | ID of radio station to use

    try:
        # Get a radio station's live broadcast stream
        api_instance.ara_content_listen_channel_id_channel_mp3_head(channel_id)
    except Exception as e:
        print("Exception when calling ChannelsApi->ara_content_listen_channel_id_channel_mp3_head: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **channel_id** | **str**| ID of radio station to use | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**302** | Redirect response |  * Location - URL of the station&#39;s broadcast stream <br>  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

