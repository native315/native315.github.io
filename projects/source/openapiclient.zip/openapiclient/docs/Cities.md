# Cities


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**right_accessory** | **str** |  | [optional] 
**items** | [**List[LeftPageRef]**](LeftPageRef.md) |  | [optional] 

## Example

```python
from openapi_client.models.cities import Cities

# TODO update the JSON string below
json = "{}"
# create an instance of Cities from a JSON string
cities_instance = Cities.from_json(json)
# print the JSON string representation of the object
print Cities.to_json()

# convert the object into a dict
cities_dict = cities_instance.to_dict()
# create an instance of Cities from a dict
cities_form_dict = cities.from_dict(cities_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


