# CountryPopularStations


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**items_type** | **str** |  | [optional] 
**items** | [**List[CountryPopularStationsItemsInner]**](CountryPopularStationsItemsInner.md) |  | [optional] 

## Example

```python
from openapi_client.models.country_popular_stations import CountryPopularStations

# TODO update the JSON string below
json = "{}"
# create an instance of CountryPopularStations from a JSON string
country_popular_stations_instance = CountryPopularStations.from_json(json)
# print the JSON string representation of the object
print CountryPopularStations.to_json()

# convert the object into a dict
country_popular_stations_dict = country_popular_stations_instance.to_dict()
# create an instance of CountryPopularStations from a dict
country_popular_stations_form_dict = country_popular_stations.from_dict(country_popular_stations_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


