# CountryPopularStationsItemsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**href** | **str** |  | [optional] 
**subtitle** | **str** |  | [optional] 
**map** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**right_accessory** | **str** |  | [optional] 
**page** | [**MoreRefPage**](MoreRefPage.md) |  | [optional] 

## Example

```python
from openapi_client.models.country_popular_stations_items_inner import CountryPopularStationsItemsInner

# TODO update the JSON string below
json = "{}"
# create an instance of CountryPopularStationsItemsInner from a JSON string
country_popular_stations_items_inner_instance = CountryPopularStationsItemsInner.from_json(json)
# print the JSON string representation of the object
print CountryPopularStationsItemsInner.to_json()

# convert the object into a dict
country_popular_stations_items_inner_dict = country_popular_stations_items_inner_instance.to_dict()
# create an instance of CountryPopularStationsItemsInner from a dict
country_popular_stations_items_inner_form_dict = country_popular_stations_items_inner.from_dict(country_popular_stations_items_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


