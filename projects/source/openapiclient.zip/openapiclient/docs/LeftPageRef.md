# LeftPageRef


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**left_accessory** | **str** |  | [optional] 
**left_accessory_count** | **int** |  | [optional] 
**page** | [**PlaceRef**](PlaceRef.md) |  | [optional] 

## Example

```python
from openapi_client.models.left_page_ref import LeftPageRef

# TODO update the JSON string below
json = "{}"
# create an instance of LeftPageRef from a JSON string
left_page_ref_instance = LeftPageRef.from_json(json)
# print the JSON string representation of the object
print LeftPageRef.to_json()

# convert the object into a dict
left_page_ref_dict = left_page_ref_instance.to_dict()
# create an instance of LeftPageRef from a dict
left_page_ref_form_dict = left_page_ref.from_dict(left_page_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


