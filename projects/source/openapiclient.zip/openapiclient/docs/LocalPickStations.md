# LocalPickStations


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**items_type** | **str** |  | [optional] 
**items** | [**List[ChannelPlaceRef]**](ChannelPlaceRef.md) |  | [optional] 

## Example

```python
from openapi_client.models.local_pick_stations import LocalPickStations

# TODO update the JSON string below
json = "{}"
# create an instance of LocalPickStations from a JSON string
local_pick_stations_instance = LocalPickStations.from_json(json)
# print the JSON string representation of the object
print LocalPickStations.to_json()

# convert the object into a dict
local_pick_stations_dict = local_pick_stations_instance.to_dict()
# create an instance of LocalPickStations from a dict
local_pick_stations_form_dict = local_pick_stations.from_dict(local_pick_stations_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


