# MoreRef


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**right_accessory** | **str** |  | [optional] 
**page** | [**MoreRefPage**](MoreRefPage.md) |  | [optional] 

## Example

```python
from openapi_client.models.more_ref import MoreRef

# TODO update the JSON string below
json = "{}"
# create an instance of MoreRef from a JSON string
more_ref_instance = MoreRef.from_json(json)
# print the JSON string representation of the object
print MoreRef.to_json()

# convert the object into a dict
more_ref_dict = more_ref_instance.to_dict()
# create an instance of MoreRef from a dict
more_ref_form_dict = more_ref.from_dict(more_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


