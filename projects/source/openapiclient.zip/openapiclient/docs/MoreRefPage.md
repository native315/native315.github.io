# MoreRefPage


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**subtitle** | **str** |  | [optional] 
**url** | **str** |  | [optional] 
**map** | **List[float]** |  | [optional] 
**count** | **int** |  | [optional] 
**utc_offset** | **int** |  | [optional] 

## Example

```python
from openapi_client.models.more_ref_page import MoreRefPage

# TODO update the JSON string below
json = "{}"
# create an instance of MoreRefPage from a JSON string
more_ref_page_instance = MoreRefPage.from_json(json)
# print the JSON string representation of the object
print MoreRefPage.to_json()

# convert the object into a dict
more_ref_page_dict = more_ref_page_instance.to_dict()
# create an instance of MoreRefPage from a dict
more_ref_page_form_dict = more_ref_page.from_dict(more_ref_page_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


