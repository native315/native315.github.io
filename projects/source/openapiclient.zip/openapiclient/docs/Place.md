# Place


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**geo** | **List[float]** |  | [optional] 
**url** | **str** |  | [optional] 
**size** | **int** |  | [optional] 
**boost** | **bool** |  | [optional] 
**title** | **str** |  | [optional] 
**country** | **str** |  | [optional] 

## Example

```python
from openapi_client.models.place import Place

# TODO update the JSON string below
json = "{}"
# create an instance of Place from a JSON string
place_instance = Place.from_json(json)
# print the JSON string representation of the object
print Place.to_json()

# convert the object into a dict
place_dict = place_instance.to_dict()
# create an instance of Place from a dict
place_form_dict = place.from_dict(place_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


