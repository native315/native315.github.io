# PlaceContent


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content** | [**List[PlaceContentContentInner]**](PlaceContentContentInner.md) |  | [optional] 

## Example

```python
from openapi_client.models.place_content import PlaceContent

# TODO update the JSON string below
json = "{}"
# create an instance of PlaceContent from a JSON string
place_content_instance = PlaceContent.from_json(json)
# print the JSON string representation of the object
print PlaceContent.to_json()

# convert the object into a dict
place_content_dict = place_content_instance.to_dict()
# create an instance of PlaceContent from a dict
place_content_form_dict = place_content.from_dict(place_content_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


