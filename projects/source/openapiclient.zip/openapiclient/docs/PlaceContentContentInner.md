# PlaceContentContentInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**items_type** | **str** |  | [optional] 
**items** | [**List[LeftPageRef]**](LeftPageRef.md) |  | [optional] 
**action_page** | [**PlaceRef**](PlaceRef.md) |  | [optional] 
**action_text** | **str** |  | [optional] 
**right_accessory** | **str** |  | [optional] 

## Example

```python
from openapi_client.models.place_content_content_inner import PlaceContentContentInner

# TODO update the JSON string below
json = "{}"
# create an instance of PlaceContentContentInner from a JSON string
place_content_content_inner_instance = PlaceContentContentInner.from_json(json)
# print the JSON string representation of the object
print PlaceContentContentInner.to_json()

# convert the object into a dict
place_content_content_inner_dict = place_content_content_inner_instance.to_dict()
# create an instance of PlaceContentContentInner from a dict
place_content_content_inner_form_dict = place_content_content_inner.from_dict(place_content_content_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


