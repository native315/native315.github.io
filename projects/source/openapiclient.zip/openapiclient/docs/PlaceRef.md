# PlaceRef


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**subtitle** | **str** |  | [optional] 
**url** | **str** |  | [optional] 
**map** | **str** |  | [optional] 
**count** | **int** |  | [optional] 
**utc_offset** | **int** |  | [optional] 

## Example

```python
from openapi_client.models.place_ref import PlaceRef

# TODO update the JSON string below
json = "{}"
# create an instance of PlaceRef from a JSON string
place_ref_instance = PlaceRef.from_json(json)
# print the JSON string representation of the object
print PlaceRef.to_json()

# convert the object into a dict
place_ref_dict = place_ref_instance.to_dict()
# create an instance of PlaceRef from a dict
place_ref_form_dict = place_ref.from_dict(place_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


