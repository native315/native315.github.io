# openapi_client.PlacesApi

All URIs are relative to *http://radio.garden/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ara_content_page_place_id_channels_get**](PlacesApi.md#ara_content_page_place_id_channels_get) | **GET** /ara/content/page/{placeId}/channels | Get a place&#39;s registered radio stations
[**ara_content_page_place_id_get**](PlacesApi.md#ara_content_page_place_id_get) | **GET** /ara/content/page/{placeId} | Get a place&#39;s details
[**ara_content_places_get**](PlacesApi.md#ara_content_places_get) | **GET** /ara/content/places | Get places with registered radio stations


# **ara_content_page_place_id_channels_get**
> AraContentPagePlaceIdChannelsGet200Response ara_content_page_place_id_channels_get(place_id)

Get a place's registered radio stations

### Example


```python
import openapi_client
from openapi_client.models.ara_content_page_place_id_channels_get200_response import AraContentPagePlaceIdChannelsGet200Response
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://radio.garden/api
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://radio.garden/api"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.PlacesApi(api_client)
    place_id = 'place_id_example' # str | ID of place to use

    try:
        # Get a place's registered radio stations
        api_response = api_instance.ara_content_page_place_id_channels_get(place_id)
        print("The response of PlacesApi->ara_content_page_place_id_channels_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PlacesApi->ara_content_page_place_id_channels_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **place_id** | **str**| ID of place to use | 

### Return type

[**AraContentPagePlaceIdChannelsGet200Response**](AraContentPagePlaceIdChannelsGet200Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ara_content_page_place_id_get**
> AraContentPagePlaceIdGet200Response ara_content_page_place_id_get(place_id)

Get a place's details

### Example


```python
import openapi_client
from openapi_client.models.ara_content_page_place_id_get200_response import AraContentPagePlaceIdGet200Response
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://radio.garden/api
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://radio.garden/api"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.PlacesApi(api_client)
    place_id = 'place_id_example' # str | ID of place to use

    try:
        # Get a place's details
        api_response = api_instance.ara_content_page_place_id_get(place_id)
        print("The response of PlacesApi->ara_content_page_place_id_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PlacesApi->ara_content_page_place_id_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **place_id** | **str**| ID of place to use | 

### Return type

[**AraContentPagePlaceIdGet200Response**](AraContentPagePlaceIdGet200Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ara_content_places_get**
> AraContentPlacesGet200Response ara_content_places_get()

Get places with registered radio stations

### Example


```python
import openapi_client
from openapi_client.models.ara_content_places_get200_response import AraContentPlacesGet200Response
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://radio.garden/api
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://radio.garden/api"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.PlacesApi(api_client)

    try:
        # Get places with registered radio stations
        api_response = api_instance.ara_content_places_get()
        print("The response of PlacesApi->ara_content_places_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PlacesApi->ara_content_places_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**AraContentPlacesGet200Response**](AraContentPlacesGet200Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

