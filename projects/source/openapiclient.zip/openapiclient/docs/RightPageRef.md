# RightPageRef


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**right_detail** | **str** |  | [optional] 
**page** | [**PlaceRef**](PlaceRef.md) |  | [optional] 

## Example

```python
from openapi_client.models.right_page_ref import RightPageRef

# TODO update the JSON string below
json = "{}"
# create an instance of RightPageRef from a JSON string
right_page_ref_instance = RightPageRef.from_json(json)
# print the JSON string representation of the object
print RightPageRef.to_json()

# convert the object into a dict
right_page_ref_dict = right_page_ref_instance.to_dict()
# create an instance of RightPageRef from a dict
right_page_ref_form_dict = right_page_ref.from_dict(right_page_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


