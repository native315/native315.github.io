# SearchResultSource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **str** |  | [optional] 
**subtitle** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**title** | **str** |  | [optional] 
**url** | **str** |  | [optional] 

## Example

```python
from openapi_client.models.search_result_source import SearchResultSource

# TODO update the JSON string below
json = "{}"
# create an instance of SearchResultSource from a JSON string
search_result_source_instance = SearchResultSource.from_json(json)
# print the JSON string representation of the object
print SearchResultSource.to_json()

# convert the object into a dict
search_result_source_dict = search_result_source_instance.to_dict()
# create an instance of SearchResultSource from a dict
search_result_source_form_dict = search_result_source.from_dict(search_result_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


