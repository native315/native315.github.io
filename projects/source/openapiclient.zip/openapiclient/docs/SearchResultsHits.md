# SearchResultsHits


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hits** | [**List[SearchResult]**](SearchResult.md) |  | [optional] 

## Example

```python
from openapi_client.models.search_results_hits import SearchResultsHits

# TODO update the JSON string below
json = "{}"
# create an instance of SearchResultsHits from a JSON string
search_results_hits_instance = SearchResultsHits.from_json(json)
# print the JSON string representation of the object
print SearchResultsHits.to_json()

# convert the object into a dict
search_results_hits_dict = search_results_hits_instance.to_dict()
# create an instance of SearchResultsHits from a dict
search_results_hits_form_dict = search_results_hits.from_dict(search_results_hits_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


