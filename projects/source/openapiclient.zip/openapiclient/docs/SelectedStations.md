# SelectedStations


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**items_type** | **str** |  | [optional] 
**items** | [**List[SelectedStationsItemsInner]**](SelectedStationsItemsInner.md) |  | [optional] 

## Example

```python
from openapi_client.models.selected_stations import SelectedStations

# TODO update the JSON string below
json = "{}"
# create an instance of SelectedStations from a JSON string
selected_stations_instance = SelectedStations.from_json(json)
# print the JSON string representation of the object
print SelectedStations.to_json()

# convert the object into a dict
selected_stations_dict = selected_stations_instance.to_dict()
# create an instance of SelectedStations from a dict
selected_stations_form_dict = selected_stations.from_dict(selected_stations_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


