# SelectedStationsItemsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**href** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**right_accessory** | **str** |  | [optional] 
**page** | [**MoreRefPage**](MoreRefPage.md) |  | [optional] 

## Example

```python
from openapi_client.models.selected_stations_items_inner import SelectedStationsItemsInner

# TODO update the JSON string below
json = "{}"
# create an instance of SelectedStationsItemsInner from a JSON string
selected_stations_items_inner_instance = SelectedStationsItemsInner.from_json(json)
# print the JSON string representation of the object
print SelectedStationsItemsInner.to_json()

# convert the object into a dict
selected_stations_items_inner_dict = selected_stations_items_inner_instance.to_dict()
# create an instance of SelectedStationsItemsInner from a dict
selected_stations_items_inner_form_dict = selected_stations_items_inner.from_dict(selected_stations_items_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


