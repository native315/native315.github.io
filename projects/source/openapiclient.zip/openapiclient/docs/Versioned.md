# Versioned


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**api_version** | **int** |  | [optional] 
**version** | **str** |  | [optional] 

## Example

```python
from openapi_client.models.versioned import Versioned

# TODO update the JSON string below
json = "{}"
# create an instance of Versioned from a JSON string
versioned_instance = Versioned.from_json(json)
# print the JSON string representation of the object
print Versioned.to_json()

# convert the object into a dict
versioned_dict = versioned_instance.to_dict()
# create an instance of Versioned from a dict
versioned_form_dict = versioned.from_dict(versioned_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


