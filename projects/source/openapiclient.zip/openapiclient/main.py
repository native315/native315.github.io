import discord
from discord.ext.commands import Bot
from discord import app_commands
import Paginator # type: ignore

import openapi_client

intents = discord.Intents.default()
bot = Bot(intents=intents,command_prefix="penis (ignore this)")

token = "nuh uh uh! (replace with your token here)"

vp = None

@bot.event
async def on_ready():
    await bot.tree.sync()
    print("grahh")

configuration = openapi_client.Configuration(
    host = "https://radio.garden/api"
)

@bot.tree.command(
    name="ping",
    description="test bot latency (especially useful for seeing the lag in the music playing.)",
)
async def ping(interaction):
    await interaction.response.send_message(f"{round(bot.latency * 1000)}ms")

@bot.tree.command(
    name="search",
    description="search for a channel or place based on your query.",
)
@app_commands.describe(query="what you want to search for")
@app_commands.rename(query='query')
async def search(interaction, query:str):
    ctx = await bot.get_context(interaction)
    with openapi_client.ApiClient(configuration) as api_client:
        # Create an instance of the API class
        api_instance = openapi_client.SearchApi(api_client)
        q = query # str | Search query

        embeds = []
        #try:
            # Search for countries, places, and radio stations
        api_response = api_instance.search_get(q)
        response_dict = api_response.to_dict()
        results = response_dict.get("hits").get("hits")
        for hit in results:
            hitsource = hit["_source"]
            embed = discord.Embed(title=f"{str(results.index(hit)+1)}/{len(results)}",
                    colour=0x00b0f4)
            embed.set_author(name=f"Results for {q}")
            embed.add_field(name="Type",
                            value=hitsource["type"],
                            inline=True)
            embed.add_field(name="Score",
                            value=hit.get("_score"),
                            inline=True)
            embed.add_field(name="Country",
                            value=hitsource["code"],
                            inline=False)
            embed.add_field(name="Title",
                            value=hitsource["title"],
                            inline=True)
            embed.add_field(name="ID",
                            value=hitsource["url"].split("/")[-1],
                            inline=True)
            embed.set_footer(text="search results")
            embeds.append(embed)

        #await interaction.response.send_message(api_response)
        await Paginator.Simple().start(ctx, pages=embeds)
        #except Exception as e:
        #    await interaction.response.send_message("Exception when calling SearchApi->search_get: %s\n" % e)
        #    print(e)
        #    pprint(api_response)
            
@bot.tree.command(
    name="info",
    description="enter id to get information",
)
@app_commands.describe(identifier="the id for the channel to get info from")
@app_commands.rename(identifier='id')
async def info(interaction, identifier:str):
    with openapi_client.ApiClient(configuration) as api_client:
        # Create an instance of the API class
        api_instance = openapi_client.ChannelsApi(api_client)
        channel_id = identifier # str | ID of radio station to use

        try:
            # Get a radio station's details
            api_response = api_instance.ara_content_channel_channel_id_get(channel_id)
            ez_api_response = api_response.to_dict()
            channel_info = ez_api_response.get("data")
            embed = discord.Embed(title=identifier,
                      description="These are the results that I got from looking up the ID you placed.",
                      colour=0x66ff00)

            embed.set_author(name="Channel Info")

            embed.add_field(name="Name",
                            value=channel_info.get("title"),
                            inline=True)
            embed.add_field(name="ID",
                            value=identifier,
                            inline=True)
            embed.add_field(name="Website",
                            value=channel_info.get("website"),
                            inline=True)
            embed.add_field(name="City/Place",
                            value=channel_info.get("place").get("title"),
                            inline=True)
            embed.add_field(name="Country",
                            value=channel_info.get("country").get("title"),
                            inline=True)

            embed.set_thumbnail(url="https://dan.onl/images/emptysong.jpg")

            embed.set_footer(text="Using openapi of radio.garden")

            await interaction.response.send_message(embed=embed)
        except Exception as e:
            await interaction.response.send_message("Exception when calling ChannelsApi->ara_content_channel_channel_id_get: %s\n" % e)

@bot.tree.command(
    name="play",
    description="enter id to play live audio",
)
@app_commands.describe(identifier="the id for the channel to play")
@app_commands.rename(identifier='id')
async def play(interaction, identifier:str):
    channel_id = identifier # str | ID of radio station to use
    if interaction.user.voice:
        vchannel = interaction.user.voice.channel
        try:
            vp = await vchannel.connect()
        except Exception as e:
            vp = bot.voice_clients[0]
            await vp.move_to(vchannel)
            vp.stop()
        audio = discord.FFmpegPCMAudio(f"http://radio.garden/api/ara/content/listen/{channel_id}/channel.mp3")
        vp.play(audio)
        await interaction.response.send_message("done")
    else:
        await interaction.response.send_message("JOIN A VOICE CHANNEL!")


@bot.tree.command(
    name="stop",
    description="stop currently playing music",
)
async def stop(interaction):
    try:
        vp = bot.voice_clients[0]
        await vp.disconnect()
        vp.cleanup()
        await interaction.response.send_message("done")
    except Exception as e:
        await interaction.response.send_message("not connected to voice")


bot.run(token)